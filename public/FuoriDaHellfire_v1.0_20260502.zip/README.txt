FuoriDaHellfire
===============

Versione: v1.0
Data: 2026-05-02
Autore: dracoroboter
Licenza: CC BY-SA 4.0

Questo pacchetto è pensato per campagne online (Roll20, VTT).
Per la stampa fisica, usare il PDF printable fullres generato separatamente.

Contenuto:
- PDF avventura lowres (senza mappe/stat block inline)
- Compendium XML FightClub (7 creature)
- 0 mappe PNG
- 7 stat block PNG
- Copertina
